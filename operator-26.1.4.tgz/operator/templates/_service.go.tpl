{{- /* GENERATED FILE DO NOT EDIT */ -}}
{{- /* Transpiled by gotohelm from "github.com/redpanda-data/redpanda-operator/operator/chart/service.go" */ -}}

{{- define "operator.StretchClusterService" -}}
{{- $dot := (index .a 0) -}}
{{- range $_ := (list 1) -}}
{{- $_is_returning := false -}}
{{- $values := $dot.Values.AsMap -}}
{{- if (not $values.multicluster.servicePerOperatorDeployment) -}}
{{- $_is_returning = true -}}
{{- (dict "r" (coalesce nil)) | toJson -}}
{{- break -}}
{{- end -}}
{{- $svcs := (coalesce nil) -}}
{{- $annotations := (default (dict) $values.annotations) -}}
{{- range $_, $p := $values.multicluster.peers -}}
{{- $svcs = (concat (default (list) $svcs) (list (mustMergeOverwrite (dict "metadata" (dict) "spec" (dict) "status" (dict "loadBalancer" (dict))) (mustMergeOverwrite (dict) (dict "apiVersion" "v1" "kind" "Service")) (dict "metadata" (mustMergeOverwrite (dict) (dict "name" (get (fromJson (include "operator.cleanForK8sWithSuffix" (dict "a" (list (printf "%s-%s" $p.name (default $dot.Chart.Name $values.nameOverride)) "raft-service")))) "r") "namespace" $dot.Release.Namespace "labels" (get (fromJson (include "operator.Labels" (dict "a" (list $dot)))) "r") "annotations" (merge (dict) $annotations (default (dict) $p.additionalAnnotation)))) "spec" (mustMergeOverwrite (dict) (dict "selector" $p.selectorOverwrite "ports" (list (mustMergeOverwrite (dict "port" 0 "targetPort" 0) (dict "port" ((9443 | int) | int) "targetPort" (9443 | int)))) "publishNotReadyAddresses" true)))))) -}}
{{- end -}}
{{- if $_is_returning -}}
{{- break -}}
{{- end -}}
{{- $_is_returning = true -}}
{{- (dict "r" $svcs) | toJson -}}
{{- break -}}
{{- end -}}
{{- end -}}

{{- define "operator.WebhookService" -}}
{{- $dot := (index .a 0) -}}
{{- range $_ := (list 1) -}}
{{- $_is_returning := false -}}
{{- $values := $dot.Values.AsMap -}}
{{- if (not $values.webhook.enabled) -}}
{{- $_is_returning = true -}}
{{- (dict "r" (coalesce nil)) | toJson -}}
{{- break -}}
{{- end -}}
{{- $_is_returning = true -}}
{{- (dict "r" (mustMergeOverwrite (dict "metadata" (dict) "spec" (dict) "status" (dict "loadBalancer" (dict))) (mustMergeOverwrite (dict) (dict "apiVersion" "v1" "kind" "Service")) (dict "metadata" (mustMergeOverwrite (dict) (dict "name" (printf "%s-webhook-service" (get (fromJson (include "operator.Name" (dict "a" (list $dot)))) "r")) "namespace" $dot.Release.Namespace "labels" (get (fromJson (include "operator.Labels" (dict "a" (list $dot)))) "r") "annotations" $values.annotations)) "spec" (mustMergeOverwrite (dict) (dict "selector" (get (fromJson (include "operator.SelectorLabels" (dict "a" (list $dot)))) "r") "ports" (list (mustMergeOverwrite (dict "port" 0 "targetPort" 0) (dict "port" ((443 | int) | int) "targetPort" (9443 | int))))))))) | toJson -}}
{{- break -}}
{{- end -}}
{{- end -}}

{{- define "operator.MetricsService" -}}
{{- $dot := (index .a 0) -}}
{{- range $_ := (list 1) -}}
{{- $_is_returning := false -}}
{{- $values := $dot.Values.AsMap -}}
{{- $_is_returning = true -}}
{{- (dict "r" (mustMergeOverwrite (dict "metadata" (dict) "spec" (dict) "status" (dict "loadBalancer" (dict))) (mustMergeOverwrite (dict) (dict "apiVersion" "v1" "kind" "Service")) (dict "metadata" (mustMergeOverwrite (dict) (dict "name" (get (fromJson (include "operator.cleanForK8sWithSuffix" (dict "a" (list (get (fromJson (include "operator.Fullname" (dict "a" (list $dot)))) "r") "metrics-service")))) "r") "namespace" $dot.Release.Namespace "labels" (get (fromJson (include "operator.Labels" (dict "a" (list $dot)))) "r") "annotations" $values.annotations)) "spec" (mustMergeOverwrite (dict) (dict "selector" (get (fromJson (include "operator.SelectorLabels" (dict "a" (list $dot)))) "r") "ports" (list (mustMergeOverwrite (dict "port" 0 "targetPort" 0) (dict "name" "https" "port" ((8443 | int) | int) "targetPort" "https")))))))) | toJson -}}
{{- break -}}
{{- end -}}
{{- end -}}

{{- define "operator.MutatingWebhookConfiguration" -}}
{{- $dot := (index .a 0) -}}
{{- range $_ := (list 1) -}}
{{- $_is_returning := false -}}
{{- $values := $dot.Values.AsMap -}}
{{- if (not $values.webhook.enabled) -}}
{{- $_is_returning = true -}}
{{- (dict "r" (coalesce nil)) | toJson -}}
{{- break -}}
{{- end -}}
{{- $_is_returning = true -}}
{{- (dict "r" (mustMergeOverwrite (dict "metadata" (dict)) (mustMergeOverwrite (dict) (dict "apiVersion" "admissionregistration.k8s.io/v1" "kind" "MutatingWebhookConfiguration")) (dict "metadata" (mustMergeOverwrite (dict) (dict "name" (printf "%s-mutating-webhook-configuration" (get (fromJson (include "operator.Fullname" (dict "a" (list $dot)))) "r")) "namespace" $dot.Release.Namespace "annotations" (dict "cert-manager.io/inject-ca-from" (printf "%s/%s" $dot.Release.Namespace (get (fromJson (include "operator.CertificateName" (dict "a" (list $dot)))) "r"))))) "webhooks" (list (mustMergeOverwrite (dict "name" "" "clientConfig" (dict) "sideEffects" (coalesce nil) "admissionReviewVersions" (coalesce nil)) (dict "admissionReviewVersions" (list "v1" "v1beta1") "clientConfig" (mustMergeOverwrite (dict) (dict "service" (mustMergeOverwrite (dict "namespace" "" "name" "") (dict "name" (printf "%s-webhook-service" (get (fromJson (include "operator.Name" (dict "a" (list $dot)))) "r")) "namespace" $dot.Release.Namespace "path" "/mutate-redpanda-vectorized-io-v1alpha1-cluster")))) "failurePolicy" "Fail" "name" "mcluster.kb.io" "rules" (list (mustMergeOverwrite (dict) (mustMergeOverwrite (dict) (dict "apiGroups" (list "redpanda.vectorized.io") "apiVersions" (list "v1alpha1") "resources" (list "clusters"))) (dict "operations" (list "CREATE" "UPDATE")))) "sideEffects" "None")))))) | toJson -}}
{{- break -}}
{{- end -}}
{{- end -}}

{{- define "operator.ValidatingWebhookConfiguration" -}}
{{- $dot := (index .a 0) -}}
{{- range $_ := (list 1) -}}
{{- $_is_returning := false -}}
{{- $values := $dot.Values.AsMap -}}
{{- if (not $values.webhook.enabled) -}}
{{- $_is_returning = true -}}
{{- (dict "r" (coalesce nil)) | toJson -}}
{{- break -}}
{{- end -}}
{{- $_is_returning = true -}}
{{- (dict "r" (mustMergeOverwrite (dict "metadata" (dict)) (mustMergeOverwrite (dict) (dict "apiVersion" "admissionregistration.k8s.io/v1" "kind" "ValidatingWebhookConfiguration")) (dict "metadata" (mustMergeOverwrite (dict) (dict "name" (printf "%s-validating-webhook-configuration" (get (fromJson (include "operator.Fullname" (dict "a" (list $dot)))) "r")) "namespace" $dot.Release.Namespace "annotations" (dict "cert-manager.io/inject-ca-from" (printf "%s/%s" $dot.Release.Namespace (get (fromJson (include "operator.CertificateName" (dict "a" (list $dot)))) "r"))))) "webhooks" (list (mustMergeOverwrite (dict "name" "" "clientConfig" (dict) "sideEffects" (coalesce nil) "admissionReviewVersions" (coalesce nil)) (dict "admissionReviewVersions" (list "v1" "v1beta1") "clientConfig" (mustMergeOverwrite (dict) (dict "service" (mustMergeOverwrite (dict "namespace" "" "name" "") (dict "name" (printf "%s-webhook-service" (get (fromJson (include "operator.Name" (dict "a" (list $dot)))) "r")) "namespace" $dot.Release.Namespace "path" "/validate-redpanda-vectorized-io-v1alpha1-cluster")))) "failurePolicy" "Fail" "name" "mcluster.kb.io" "rules" (list (mustMergeOverwrite (dict) (mustMergeOverwrite (dict) (dict "apiGroups" (list "redpanda.vectorized.io") "apiVersions" (list "v1alpha1") "resources" (list "clusters"))) (dict "operations" (list "CREATE" "UPDATE")))) "sideEffects" "None")))))) | toJson -}}
{{- break -}}
{{- end -}}
{{- end -}}

